#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "bf.h"
#include "bp_file.h"
#include "record.h"
#include <bp_datanode.h>
#include <stdbool.h>
#define MAX_RECORDS_PER_BLOCK ((BF_BLOCK_SIZE - sizeof(char) - sizeof(int)) / sizeof(Record))
#define bplus_ERROR -1

#define CALL_BF(call)         \
  {                           \
    BF_ErrorCode code = call; \
    if (code != BF_OK)        \
    {                         \
      BF_PrintError(code);    \
      return bplus_ERROR;     \
    }                         \
  }

int BP_CreateFile(char *fileName) {
    int file_desc;
    BF_Block *block;

    // Create the file using BF_CreateFile
    CALL_BF(BF_CreateFile(fileName));
    CALL_BF(BF_OpenFile(fileName, &file_desc));

    // Allocate the first block
    BF_Block_Init(&block);
    CALL_BF(BF_AllocateBlock(file_desc, block));

    // Write metadata to the first block
    char *data = BF_Block_GetData(block);
    memset(data, 0, BF_BLOCK_SIZE);

    BPLUS_INFO *info = (BPLUS_INFO *)data;
    strcpy(info->file_type, "B+T");
    info->root_block = -1;  // No root
    info->tree_height = 0;  // Empty 
    info->block_count = 1;  // metadata

    // dirty kai unpin
    BF_Block_SetDirty(block);
    CALL_BF(BF_UnpinBlock(block));
    BF_Block_Destroy(&block);
    CALL_BF(BF_CloseFile(file_desc));

return 0;
}


BPLUS_INFO* BP_OpenFile(char *fileName, int *file_desc) {
    BF_Block *block;
    BPLUS_INFO *info;
    if (BF_OpenFile(fileName, file_desc) != BF_OK) {
        fprintf(stderr, "Error opening file: %s\n", fileName);
        return NULL;
    }
    BF_Block_Init(&block);
    if (BF_GetBlock(*file_desc, 0, block) != BF_OK) {
        fprintf(stderr, "Error reading metadata block: %s\n", fileName);
        BF_CloseFile(*file_desc);
        return NULL;
    }
// metadata
    char *data = BF_Block_GetData(block);
    info = (BPLUS_INFO *)malloc(sizeof(BPLUS_INFO));
    memcpy(info, data, sizeof(BPLUS_INFO));

    // isws kai na mhn xreiazetai alla den eimai sigouros
    if (strncmp(info->file_type, "B+T", 3) != 0) {
        fprintf(stderr, "Invalid file type for B+-tree: %s\n", fileName);
        free(info);
        BF_UnpinBlock(block);
        BF_Block_Destroy(&block);
        BF_CloseFile(*file_desc);
        return NULL;
    }

//unpin
    if (BF_UnpinBlock(block) != BF_OK) {
        fprintf(stderr, "Error unpinning metadata block: %s\n", fileName);
        free(info);
        BF_Block_Destroy(&block);
        BF_CloseFile(*file_desc);
        return NULL;
    }
    BF_Block_Destroy(&block);

    return info;
}

int BP_CloseFile(int file_desc, BPLUS_INFO* info) {
    // Fre
    if (info != NULL) {
        free(info);
    }
    if (BF_CloseFile(file_desc) != BF_OK) {
        fprintf(stderr, "Error closing file descriptor: %d\n", file_desc);
        return -1;
    }

    return 0;
}

int BP_InsertEntry(int file_desc, BPLUS_INFO *bplus_info, Record record) {
    BF_Block *block, *new_block;
    char *data, *new_data;
    int current_block = bplus_info->root_block; //riza
    int block_count; // athrisma blocks

    BF_Block_Init(&block);

// keno dentro
    if (current_block == -1) {
        printf("Tree is empty. Creating root node...\n");
        CALL_BF(BF_AllocateBlock(file_desc, block));
        data = BF_Block_GetData(block); 
        memset(data, 0, BF_BLOCK_SIZE); 

        data[0] = 'L'; // fullo

        int *num_records = (int *)(data + sizeof(char)); 
        *num_records = 1; 

        Record *records = (Record *)(data + sizeof(char) + sizeof(int)); // Pointer to the records array
        records[0] = record; // root

        CALL_BF(BF_GetBlockCounter(file_desc, &block_count)); // sum of blockz
        bplus_info->root_block = block_count - 1; // h riza einai twra to neo block
        bplus_info->tree_height = 1; // upsos=1
        bplus_info->block_count = block_count; // metadata

        BF_Block_SetDirty(block); // dirty
        CALL_BF(BF_UnpinBlock(block)); // Unpin
        BF_Block_Destroy(&block); // Destroy
        return 0; // ola ok
    }

    while (1) {
        CALL_BF(BF_GetBlock(file_desc, current_block, block));
        data = BF_Block_GetData(block); 
        char block_type = data[0]; // ti block exw? L gia fullo(leaf), I gia eswteriko node (internal)

        if (block_type == 'L') {
            break; // eftasa se fullo
        }

        int *keys = (int *)(data + sizeof(char)); // Pointer to the keys array
        int num_keys = *((int *)(data + sizeof(char) + sizeof(int))); // Number of keys in the block
        int *children = (int *)(data + sizeof(char) + 2 * sizeof(int)); // Pointer to the children array

        int i;
        for (i = 0; i < num_keys; i++) { // loop
            if (record.id < keys[i]) { // vres to paidi me vasi to record id
                current_block = children[i]; //  
                break; // an vrw to paidi stamataw na psaxnw 
            }
        }
        if (i == num_keys) { // an den vrw mikrotero klidi, paw sto pio deksia paidi 
            current_block = children[num_keys];
        }

        CALL_BF(BF_UnpinBlock(block)); // Unpin 
    }

  
    int *num_records = (int *)(data + sizeof(char)); // Pointer to the number of records in the block
    Record *records = (Record *)(data + sizeof(char) + sizeof(int)); // Pointer ston pinaka twn records
    for (int i = 0; i < *num_records; i++) { // loop gia ta records
        if (records[i].id == record.id) { // an yparxei record me to idio ID
            printf("Duplicate record detected: ID = %d. Skipping insertion.\n", record.id);
            BF_Block_SetDirty(block); // dirty
            CALL_BF(BF_UnpinBlock(block)); // Unpin 
            BF_Block_Destroy(&block); // Destroy
            return 0; // an exw duplicate entry den to vazw
        }
    }

    // insert kai spasimo dentrou
    if (*num_records < MAX_RECORDS_PER_BLOCK) { // efoson exei xwro
        // Insert
        int i;
        for (i = *num_records - 1; i >= 0 && records[i].id > record.id; i--) { // efoson to record id pou exoume authn thn stigmh einai megalutero apo to neo record
            records[i + 1] = records[i]; // sort meta thn eisagwgh
        }
        records[i + 1] = record; // neo record ston pinaka
        (*num_records)++; // auksisi ta records
        BF_Block_SetDirty(block); // dirty
        CALL_BF(BF_UnpinBlock(block)); // Unpin
        BF_Block_Destroy(&block); // Destroy
        return 0; // sucesss
    }

    // spasimo dentrou
    BF_Block_Init(&new_block); // neo block gia to spasimo
    CALL_BF(BF_AllocateBlock(file_desc, new_block)); // neo block alloc
    new_data = BF_Block_GetData(new_block); // data pointer gia to neo block
    memset(new_data, 0, BF_BLOCK_SIZE); // arxikopoihsh me 0
    new_data[0] = 'L'; // fullo

    int *new_num_records = (int *)(new_data + sizeof(char));
    *new_num_records = 0; // plithos record gia to neo block

    Record *new_records = (Record *)(new_data + sizeof(char) + sizeof(int)); // pointer gia ta records sto neo block Pointer
    int mid = MAX_RECORDS_PER_BLOCK / 2; // mesh timh gia na spasw to dentro

    // Move half the records to the new block
    for (int i = mid; i < MAX_RECORDS_PER_BLOCK; i++) { // arxizo apo thn mesi, afou kanw split to dentro
        new_records[*new_num_records] = records[i]; // copy sto neo block 
        (*new_num_records)++;
    }
    *num_records = mid; // record count gia to arxiko block

    // Insert into the correct block
    if (record.id < new_records[0].id) { // elegxos gia na katalavw an anhkei sto arxiko h sto neo block
        int i;
        for (i = *num_records - 1; i >= 0 && records[i].id > record.id; i--) { // vres thn thesi sto arxiko block
            records[i + 1] = records[i]; // Shift records gia na kanw xwro
        }
        records[i + 1] = record; //  to record tha paei sto arxiko block
        (*num_records)++; 
    } else { // to record tha paei sto neo block
        int i;
        for (i = *new_num_records - 1; i >= 0 && new_records[i].id > record.id; i--) { // vres thn thesi sto neo block
            new_records[i + 1] = new_records[i]; // Shift records gia na kanw xwro
        }
        new_records[i + 1] = record; // vale to record sto block
        (*new_num_records)++; // elegxos sto epomeno
    }

    BF_Block_SetDirty(block); // Mark original block san modified
    BF_Block_SetDirty(new_block); // Mark new block san modified
    CALL_BF(BF_UnpinBlock(block)); // Unpin original block
    CALL_BF(BF_UnpinBlock(new_block)); // Unpin new block
    BF_Block_Destroy(&block); // Destroy original block 
    BF_Block_Destroy(&new_block); // Destroy new block 
    printf("Split complete. Left block records: %d, Right block records: %d\n", *num_records, *new_num_records);
    return 0; //sucesss
}


int BP_GetEntry(int file_desc, BPLUS_INFO *bplus_info, int id, Record **result) {
    BF_Block *block; // pointer gia  ta BF funcs.
    char *data; // gia na ftanw ta block data
    int current_block = bplus_info->root_block; // root block

    BF_Block_Init(&block); // Init.

    while (current_block != -1) { // look mexri na mjn uparxoun alla blocks
        CALL_BF(BF_GetBlock(file_desc, current_block, block)); 
        data = BF_Block_GetData(block);

        char block_type = data[0]; //To prwto byte mas leei ti einai (riza , fullo ktlp) 
        printf("Traversing Block ID: %d, Block Type: %c\n", current_block, block_type); // debugging

        if (block_type == 'L') { // elegxos an einai fullo
            int *num_records = (int *)(data + sizeof(char)); // pinakas sto plithos records
            Record *records = (Record *)(data + sizeof(char) + sizeof(int)); // pointer ston pinaka records

            for (int i = 0; i < *num_records; i++) { // Iterate through the records
                if (records[i].id == id) { // an to record ID einai idio me auto pou psaxnoume 
                    *result = malloc(sizeof(Record)); // afou to vrika, krataw xwro gia thn apothikefsi
                    memcpy(*result, &records[i], sizeof(Record)); // copy to record pou brikame sto apotelesma
                    BF_Block_Destroy(&block); 
                    printf("Record found in leaf block: ID = %d\n", id); // debugging
                    return 0; // record found
                }
            }

            BF_Block_Destroy(&block); 
            printf("Record with ID %d not found in current leaf.\n", id); // debugging
            return -1; //not found
        }

        
        int *keys = (int *)(data + sizeof(char)); // pointer ston pinaka me ta klidia 
        int num_keys = *((int *)(data + sizeof(char) + sizeof(int))); //plithos klidiwn 
        int *children = (int *)(data + sizeof(char) + 2 * sizeof(int)); // pointer ston pinaka apo pointers twn paidiwn 

        printf("Internal Node Keys: "); // gia debug
        for (int i = 0; i < num_keys; i++) { // debug , mporoume na to svisoume an den to theloume
            printf("%d ", keys[i]);
        }
        printf("\n");

        int i;
        for (i = 0; i < num_keys; i++) { // traverse gia ta paidia
            if (id < keys[i]) { // an to id einai mikrotero apo to key pou exoume twra 
                current_block = children[i]; //  to block  ginetai to antistoixo paiddi
                break;
            }
        }
        if (i == num_keys) { // an to ID einai megalutero apo kathe key, phgaine sto pio deksia paidi(afou den to vrikame sto loop)  
            current_block = children[num_keys];
        }

        CALL_BF(BF_UnpinBlock(block));
    }

    BF_Block_Destroy(&block); 
    return -1; // an den vrw to record
}
